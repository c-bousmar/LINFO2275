from Game.BoardGame import BoardGame

from Simulator.BoardGameSimulator import BoardGameSimulator
from Simulator.DiceStrategy import DiceStrategy

# Put all the layouts in this list
layouts = [
    [0] * 15,
    [0] + [1] * 13 + [0],
    [0] + [2] * 13 + [0],
    [0] + [3] * 13 + [0],
    [0] + [4] * 13 + [0]
]

# Put all the strategies here (there must exist and be implemented in Simulator.DiceStrategy class)
strategies = [
            "Optimal_MDP",
            "Optimal_QLearning",
            "Always_Security",
            "Always_Normal",
            "Always_Risky",
            "Random"
        ]

# Choose the number of simulation per position for each layout
n_simulations = 100

if __name__ == "__main__":
    
    for circle in [False, True]:
        for layout in layouts:
            board = BoardGame(layout, circle)
            dice_strategy = DiceStrategy(board, strategies)
            board.display_board()
            game_simulator = BoardGameSimulator(board, dice_strategy, n_simulations=n_simulations)
            game_simulator.compare_strategies()