import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

data = pd.read_csv("Results/simulations.csv")
strategies = data['Strategy'].unique()

expectation_columns = [f'Expectation_{i}' for i in range(14)]

expectation_matrix = pd.DataFrame(columns=[f'Pos_{i}' for i in range(14)])

for strategy in strategies:
    strategy_data = data[data['Strategy'] == strategy]
    expectation_matrix.loc[strategy] = [strategy_data[f'Expectation_{i}'].values[0] for i in range(14)]

plt.figure(figsize=(14, 10))
sns.heatmap(expectation_matrix, annot=True, cmap='Blues', cbar=True, linewidths=0.5, fmt='.2f')
plt.title("Expectation Values Across Different Strategies", fontsize=20, fontweight='bold')
plt.xlabel("Position on Board", fontsize=14)
plt.ylabel("Strategies", fontsize=14)
plt.tight_layout()
plt.show()



import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Charger les données
data = pd.read_csv("Results/simulations.csv")
strategies = data['Strategy'].unique()

layout_columns = [f'Layout_Pos_{i}' for i in range(15)]
layout = data[layout_columns].iloc[0].tolist()
circle = data["Circle"][0]

from Algorithms.MarkovDecision import markovDecision
expect_theorical = markovDecision(layout, circle)[0]

expectation_matrix = pd.DataFrame(columns=['Strategy'] + [f'Pos_{i}' for i in range(14)])

for strategy in strategies:
    strategy_data = data[data['Strategy'] == strategy]
    row = {'Strategy': strategy}
    row.update({f'Pos_{i}': strategy_data[f'Expectation_{i}'].values[0] for i in range(14)})
    expectation_matrix = pd.concat([expectation_matrix, pd.DataFrame([row])], ignore_index=True)
    
result_dict = {'Strategy': 'MDP-Theorical'}
for i, value in enumerate(expect_theorical):
    result_dict[f'Pos_{i}'] = np.float64(value)
expectation_matrix = pd.concat([expectation_matrix, pd.DataFrame([result_dict])], ignore_index=True)


expectation_melted = expectation_matrix.melt(id_vars=['Strategy'], var_name='Position', value_name='Expectation')

expectation_melted['Position'] = expectation_melted['Position'].str.extract('(\d+)').astype(int)

plt.figure(figsize=(14, 8))
sns.lineplot(data=expectation_melted, x='Position', y='Expectation', hue='Strategy', marker="o", linewidth=2.5)

plt.title("Évolution des Espérances selon la Position et la Stratégie", fontsize=18, fontweight='bold')
plt.xlabel("Position sur le plateau", fontsize=14)
plt.ylabel("Valeur d'espérance", fontsize=14)
plt.legend(title="Stratégies")
plt.grid(True, linestyle='--', alpha=0.7)
plt.show()
