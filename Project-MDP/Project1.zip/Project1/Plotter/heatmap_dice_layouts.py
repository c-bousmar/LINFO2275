import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

data = pd.read_csv("Results/simulations.csv")
optimal_strategy = data[data['Strategy'] == 'Optimal_MDP']

security_columns = [f'SECURITY_Prob_Pos_{i}' for i in range(14)]
normal_columns = [f'NORMAL_Prob_Pos_{i}' for i in range(14)]
risky_columns = [f'RISKY_Prob_Pos_{i}' for i in range(14)]

means_matrix = pd.DataFrame(columns=["SECURITY", "NORMAL", "RISKY"], index=[f'Layout_{i+1}' for i in range(len(optimal_strategy))])

for index, row in optimal_strategy.iterrows():
    means_matrix.loc[f'Layout_{index+1}', "SECURITY"] = row[security_columns].mean()
    means_matrix.loc[f'Layout_{index+1}', "NORMAL"] = row[normal_columns].mean()
    means_matrix.loc[f'Layout_{index+1}', "RISKY"] = row[risky_columns].mean()

means_matrix = means_matrix.astype(float)
means_matrix = means_matrix.fillna(0)

plt.figure(figsize=(14, 10))
sns.heatmap(means_matrix, annot=True, cmap='Blues', cbar=True, linewidths=0.5, fmt='.2f')
plt.title("Mean Dice Probability by Layout", fontsize=20, fontweight='bold')
plt.xlabel("Dice Type", fontsize=14)
plt.ylabel("Layouts", fontsize=14)
plt.tight_layout()
plt.show()


# plt.figure(figsize=(12, 6))

# for strategy in data['Strategy']:
#     strategy_data = data[data['Strategy'] == strategy]
#     theoretical = [strategy_data[f'Expectation_{i}'].values[0] for i in range(14)]
#     empirical = [strategy_data[f'Empirical_Cost_{i}'].values[0] for i in range(14)]  # Ajouter cette colonne dans tes simulations
    
#     plt.plot(range(14), theoretical, label=f"{strategy} - Théorique", linestyle="dashed")
#     plt.plot(range(14), empirical, label=f"{strategy} - Empirique")

# plt.xlabel("Position sur le plateau")
# plt.ylabel("Coût moyen")
# plt.title("Comparaison Théorique vs Empirique des Attentes")
# plt.legend()
# plt.grid()
# plt.show()
