#!/bin/bash

MARKOV_DAT="Results/Memory/Dat/markov_memory_results.dat"
QLEARNING_DAT="Results/Memory/Dat/qlearning_memory_results.dat"
GRAPH_SCRIPT="Graphs/Script/graph.py"
ROOT="Project1/"
rm -f "$MARKOV_DAT"
rm -f "$QLEARNING_DAT"

layout="[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]"
cycle="False"
interval="0.1"
LIMIT=50
for i in $(seq 1 $LIMIT); do
    echo "Iteration $i"
    echo "🔹 Profiling Markov Decision..."
    mprof run --interval $interval --include --output  $MARKOV_DAT python3 -c "import main; main.markovDecision($layout, $cycle)"
    echo "✅ Markov profiling done."
    echo "🔹 Profiling Q-Learning Decision..."
    mprof run --interval $interval --include --output $QLEARNING_DAT python3 -c "import main; main.QLearningDecision($layout, $cycle, display_board=False)"
    echo "✅ Q-Learning profiling done."
done

FILES=($MARKOV_DAT $QLEARNING_DAT)

for FILE in "${FILES[@]}"; do
    while [[ ! -f "$FILE" ]]; do
        sleep 1
    done
done

echo "🔹 Generation of the memory consumption graph..."
python3 $GRAPH_SCRIPT
echo "✅ Generation of the memory consumption graph done"

