import psutil
from Game.TransitionManager import TransitionManager

import numpy as np
import time
import os
import csv

class BoardGameSimulator:
    """
    Simulates multiple games on a board using different dice strategies.
    Records simulation results, including steps taken, elapsed time, dice policies, and expectations.
    Results are saved to a CSV file for further analysis.
    """
    
    def __init__(self, board, dice_strategies, n_simulations=1000, save_path="Results/"):
        """
        Initializes the simulator with a board, dice strategies, and simulation settings.

        Args:
            board (BoardGame): The game board to simulate on.
            dice_strategies (DiceStrategies): A collection of strategies for choosing dice.
            n_simulations (int): Number of simulations to run for each strategy.
            save_path (str): Directory to save simulation results.
        """
        self.board = board 
        self.tm = TransitionManager(board)
        self.dice_strategies = dice_strategies
        self.n_simulations = n_simulations
        self.save_path = save_path
        self.results_file = os.path.join(save_path, "simulations.csv")

        os.makedirs(self.save_path, exist_ok=True)
        self._initialize_results_file()


    def _initialize_results_file(self):
        """Create CSV results file with structured headers."""
        if not os.path.exists(self.results_file):
            headers = [
                "Strategy", 
                "Average Expectation", 
                "Elapsed Time",
                "Memory",
                *[f"Expectation_{i}" for i in range(14)],
                *[f"SECURITY_Prob_Pos_{i}" for i in range(14)],
                *[f"NORMAL_Prob_Pos_{i}" for i in range(14)],
                *[f"RISKY_Prob_Pos_{i}" for i in range(14)],
                *[f"Layout_Pos_{i}" for i in range(15)],
                "Circle"
            ]
            with open(self.results_file, 'w', newline='') as f:
                csv.writer(f).writerow(headers)

    def _record_strategy_results(self, strategy_name, elapsed_time, memory_usage, 
                                expectation_results, 
                                mean_probabilities_security,
                                mean_probabilities_normal,
                                mean_probabilities_risky):
        """Format results correctly for CSV output."""
        row = [
            strategy_name,
            np.mean(expectation_results),
            elapsed_time,
            memory_usage,
            *expectation_results,
            *mean_probabilities_security,
            *mean_probabilities_normal,
            *mean_probabilities_risky,
            *self.board.layout,
            self.board.circle
        ]

        with open(self.results_file, 'a', newline='') as f:
            csv.writer(f).writerow(row)


    def compare_strategies(self):
        """Runs simulations for all strategies and saves the results to a CSV file."""
        for strategy_name, strategy in self.dice_strategies.strategies.items():
            print(f"=== Running simulations for strategy: {strategy_name} ===")
            self._evaluate_strategy(strategy, strategy_name)
            print(f"=== Completed: {strategy_name} ===\n\n")
    
    
    def _evaluate_strategy(self, strategy, strategy_name):
        """
        Runs multiple simulations for a given strategy and records the results.
        Args:
            strategy (function): The strategy function to use for choosing dice.
            strategy_name (str): Name of the strategy (for logging and saving results).
        """
        num_positions = 14
        expectation_results = []
        dice_policies = []
        dice_counts = []
        start_time = time.time()
        start_memory = psutil.Process().memory_info().rss / (1024 * 1024)  # Memory in MB
  
        for position in range(num_positions):
            steps_data, policy_data, count_data = self._simulate_position(position, strategy)

            expectation_results.append(np.mean(steps_data))
            if position == 0:
                dice_policies.extend(policy_data)
                dice_counts.extend(count_data)
        
        end_time = time.time()
        end_memory = psutil.Process().memory_info().rss / (1024 * 1024)
        elapsed_time = end_time - start_time
        memory_usage = end_memory - start_memory

        all_probabilities_security = [policy[0] for policy in dice_policies]
        mean_probabilities_security = self._compute_position_averages(all_probabilities_security, dice_counts)
        
        all_probabilities_normal = [policy[1] for policy in dice_policies]
        mean_probabilities_normal = self._compute_position_averages(all_probabilities_normal, dice_counts)
        
        all_probabilities_risky = [policy[2] for policy in dice_policies]
        mean_probabilities_risky = self._compute_position_averages(all_probabilities_risky, dice_counts)
            
        self._display_result(mean_probabilities_security, mean_probabilities_normal, mean_probabilities_risky, expectation_results, elapsed_time)
        
        self._record_strategy_results(
            strategy_name,
            elapsed_time,
            memory_usage,
            expectation_results,
            mean_probabilities_security,
            mean_probabilities_normal,
            mean_probabilities_risky
        )

    
    def _simulate_position(self, start_pos, strategy):
        """Run simulations for a single starting position."""
        steps_log = []
        policy_log = []
        count_log = []

        for _ in range(self.n_simulations):
            game_steps, policies, counts = self._run_single_simulation(start_pos, strategy)
            steps_log.append(game_steps)
            policy_log.append(policies)
            count_log.append(counts)

        return steps_log, policy_log, count_log


    def _run_single_simulation(self, start_pos, strategy):
        """Execute a single game simulation from specified starting position."""
        position_counts = np.zeros(14, dtype=int)
        dice_choices = np.zeros((3, 14))  # 3 dice types, 14 positions
        current_state = self.board.states[start_pos]
        total_steps = 0
        max_steps = 100

        while current_state.position != self.board.last_cell and total_steps < max_steps:
            curr_pos = current_state.position
            die = strategy(curr_pos)
            move = die.roll()

            # Update dice selection tracking
            position_counts[curr_pos] += 1
            dice_choices[die.type.value - 1, curr_pos] += 1

            # Determine movement parameters
            offset_options = [0, 8] if (curr_pos + 1 == self.board.slow_lane.start) else [0]
            offset = np.random.choice(offset_options)

            # Execute move
            new_pos = self.tm.get_next_position(curr_pos, move, offset)
            new_state = self.board.states[new_pos]

            # Handle special events
            if die.is_triggering_event():
                updated_pos, penalty = self.tm.handling_events(new_state)
                total_steps += penalty
                new_state = self.board.states[updated_pos]

            current_state = new_state
            total_steps += 1

        # Calculate dice probabilities while handling division
        with np.errstate(divide='ignore', invalid='ignore'):
            dice_probs = dice_choices / position_counts
            dice_probs = np.nan_to_num(dice_probs)

        return total_steps, dice_probs, position_counts


    def _display_result(self, mean_probabilities_security, mean_probabilities_normal, mean_probabilities_risky, expectations, elapsed_time):
        """Display all the results."""
        print(f"\nSECURITY Prob:\t", end='')
        for prob in mean_probabilities_security:
            print(f"{prob:.2%}\t", end='')
        
        print(f"\nNORMAL Prob:\t", end='')
        for prob in mean_probabilities_normal:
            print(f"{prob:.2%}\t", end='')
        
        print(f"\nRISKY Prob:\t", end='')
        for prob in mean_probabilities_risky:
            print(f"{prob:.2%}\t", end='')
            
        print("\nExpectation:\t", end='')
        for expectation in expectations:
            print(f"{float(expectation):.2f}\t", end='')
        print(f"\nElapsed Time:\t{elapsed_time:.3f} seconds\n")


    @staticmethod
    def _compute_position_averages(probabilities, counts):
        """Calculate average probabilities accounting for unvisited positions."""
        summed = np.zeros(14)
        valid_counts = np.zeros(14)

        for prob_arr, count_arr in zip(probabilities, counts):
            summed += prob_arr
            valid_counts += (count_arr > 0)

        with np.errstate(divide='ignore', invalid='ignore'):
            averages = summed / valid_counts
            return np.nan_to_num(averages)