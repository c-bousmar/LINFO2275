import pandas as pd

# Charger les données dans un DataFrame
data = pd.read_csv('Results/simulations.csv')

# Grouper par stratégie et calculer la moyenne
performance = data.groupby('Strategy')[['Average Expectation', 'Elapsed Time']].mean()
print(performance)

# Extraire les colonnes de layout
layout_columns = [col for col in data.columns if col.startswith('Layout_Pos_')]

# Comparer les stratégies pour chaque layout
for layout in layout_columns:
    layout_performance = data.groupby('Strategy')[layout].mean()
    print(f"Performance pour {layout}:\n{layout_performance}\n")
    
# Calculer la moyenne des probabilités par stratégie
security_probs = data[[col for col in data.columns if col.startswith('SECURITY_Prob_Pos_')]].mean(axis=1)
normal_probs = data[[col for col in data.columns if col.startswith('NORMAL_Prob_Pos_')]].mean(axis=1)
risky_probs = data[[col for col in data.columns if col.startswith('RISKY_Prob_Pos_')]].mean(axis=1)

# Ajouter ces moyennes au DataFrame
data['Avg_Security_Prob'] = security_probs
data['Avg_Normal_Prob'] = normal_probs
data['Avg_Risky_Prob'] = risky_probs

# Comparer les stratégies
strategy_probs = data.groupby('Strategy')[['Avg_Security_Prob', 'Avg_Normal_Prob', 'Avg_Risky_Prob']].mean()
print(strategy_probs)

import matplotlib.pyplot as plt
import seaborn as sns

# Comparaison des stratégies par layout
plt.figure(figsize=(12, 6))
sns.boxplot(x='Strategy', y='Layout_Pos_0', data=data)
plt.title('Performance des stratégies pour Layout_Pos_0')
plt.show()

# Comparaison des probabilités de décision
strategy_probs.plot(kind='bar', stacked=True, figsize=(12, 6))
plt.title('Probabilités de décision par stratégie')
plt.ylabel('Probabilité moyenne')
plt.show()